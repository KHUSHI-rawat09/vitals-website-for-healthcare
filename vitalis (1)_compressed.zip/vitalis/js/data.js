/* Seed data (fictional patient) + simple Hindi medical dictionary */
window.VITALIS_SEED = function (h) {
  const v1 = 'v' + Math.random().toString(36).slice(2, 8);
  const v2 = 'v' + Math.random().toString(36).slice(2, 8);
  const v3 = 'v' + Math.random().toString(36).slice(2, 8);
  const f1 = 'f' + Math.random().toString(36).slice(2, 8);
  return {
    user: null,
    activeId: 'p1',
    shares: [],
    profiles: [
      {
        id: 'p1', name: 'Ramesh Verma', relation: 'Self', age: 58,
        allergyStatus: 'unknown', allergies: [], conditions: ['Type 2 Diabetes', 'High blood pressure'],
        bloodGroup: 'B+', emergency: null,
        visits: [
          { id: v3, date: h.addDays(-30), doctor: '', hospital: 'Primary Health Centre, Dehradun', reason: 'BP check',
            notes: 'BP was high. New tablet started.', medicines: [{ name: 'Amlodipine', dose: '5mg OD' }], reports: [], followUpAdvised: true },
          { id: v2, date: h.addDays(-120), doctor: 'Dr. Anil Mehta', hospital: 'Doon Diabetes Clinic', reason: 'Routine diabetes check',
            notes: 'Sugar control okay. Repeat HbA1c after 3 months.', medicines: [{ name: 'Metformin', dose: '500mg BD' }],
            reports: [{ name: 'HbA1c: 7.9%' }, { name: 'Fasting sugar report' }], followUpAdvised: true },
          { id: v1, date: h.addDays(-240), doctor: 'Dr. Sunita Rao', hospital: 'City Hospital', reason: 'Fever and cough',
            notes: '', medicines: [{ name: 'Azithromycin', dose: '500mg OD' }, { name: 'Paracetamol', dose: '' }],
            reports: [{ name: 'Chest X-ray' }], followUpAdvised: false }
        ],
        followUps: [
          { id: f1, title: 'Repeat HbA1c test', date: h.addDays(-21), status: 'pending', visitId: v2 }
        ]
      },
      {
        id: 'p2', name: 'Meera Verma', relation: 'Wife', age: 55,
        allergyStatus: 'listed', allergies: ['Penicillin'], conditions: [], bloodGroup: '',
        emergency: { name: 'Ramesh Verma', phone: '9000000000' }, visits: [], followUps: []
      }
    ]
  };
};

/* term -> simple Hindi. This is an explanation aid, NOT a diagnosis. */
window.VITALIS_TERMS = [
  ['hypertension', 'High blood pressure (हाई बीपी) — खून का दबाव सामान्य से ज़्यादा रहना।'],
  ['hypotension', 'Low blood pressure (लो बीपी) — खून का दबाव सामान्य से कम रहना।'],
  ['diabetes mellitus', 'Diabetes (शुगर) — खून में शुगर की मात्रा ज़्यादा रहना।'],
  ['diabetes', 'Diabetes (शुगर) — खून में शुगर की मात्रा ज़्यादा रहना।'],
  ['hba1c', 'पिछले लगभग 3 महीनों की औसत शुगर बताने वाली जाँच।'],
  ['fasting', 'खाली पेट (कुछ खाए बिना) की जाँच।'],
  ['post-prandial', 'खाना खाने के बाद की जाँच।'],
  ['hemoglobin', 'खून में मौजूद वह तत्व जो ऑक्सीजन ले जाता है। कम होने पर कमज़ोरी महसूस हो सकती है।'],
  ['anemia', 'खून की कमी — हीमोग्लोबिन का कम होना।'],
  ['cbc', 'पूरे खून की जाँच (खून की कोशिकाओं की गिनती)।'],
  ['wbc', 'सफ़ेद रक्त कोशिकाएँ — शरीर को संक्रमण से लड़ने में मदद करती हैं।'],
  ['rbc', 'लाल रक्त कोशिकाएँ — पूरे शरीर में ऑक्सीजन पहुँचाती हैं।'],
  ['platelets', 'खून जमाने में मदद करने वाली कोशिकाएँ।'],
  ['creatinine', 'किडनी कैसे काम कर रही है, यह बताने वाली जाँच।'],
  ['cholesterol', 'खून में चर्बी जैसा पदार्थ। ज़्यादा होने पर दिल की बीमारी का खतरा बढ़ सकता है।'],
  ['ldl', '"खराब" कोलेस्ट्रॉल।'],
  ['hdl', '"अच्छा" कोलेस्ट्रॉल।'],
  ['triglycerides', 'खून में मौजूद एक तरह की चर्बी।'],
  ['dyslipidemia', 'खून में चर्बी (कोलेस्ट्रॉल) का असंतुलन।'],
  ['thyroid', 'गले की एक ग्रंथि जो शरीर की ऊर्जा और मेटाबॉलिज़्म नियंत्रित करती है।'],
  ['tsh', 'थायराइड ठीक से काम कर रहा है या नहीं, यह बताने वाली जाँच।'],
  ['ecg', 'दिल की धड़कन की बिजली-गतिविधि की जाँच।'],
  ['x-ray', 'हड्डियों और छाती आदि की तस्वीर लेने की जाँच।'],
  ['ultrasound', 'आवाज़ की तरंगों से अंदर के अंगों की तस्वीर।'],
  ['mri', 'चुंबकीय तरंगों से शरीर के अंदर की विस्तृत तस्वीर।'],
  ['ct scan', 'कई एक्स-रे से बनी शरीर के अंदर की विस्तृत तस्वीर।'],
  ['antibiotic', 'बैक्टीरिया से होने वाले संक्रमण की दवा। डॉक्टर के बताए पूरे दिन तक लें।'],
  ['analgesic', 'दर्द कम करने वाली दवा।'],
  ['antipyretic', 'बुखार कम करने वाली दवा।'],
  ['antacid', 'पेट की जलन/एसिडिटी कम करने वाली दवा।'],
  ['inflammation', 'सूजन या जलन।'],
  ['infection', 'कीटाणुओं (बैक्टीरिया/वायरस) की वजह से होने वाली बीमारी।'],
  ['gastritis', 'पेट की अंदरूनी परत में जलन या सूजन।'],
  ['migraine', 'तेज़ सिरदर्द, अक्सर सिर के एक तरफ।'],
  ['asthma', 'साँस की नलियों का सिकुड़ना, जिससे साँस लेने में तकलीफ होती है।'],
  ['bronchitis', 'साँस की नलियों में सूजन, जिससे खाँसी होती है।'],
  ['typhoid', 'गंदे पानी/खाने से फैलने वाला बुखार।'],
  ['dengue', 'मच्छर के काटने से फैलने वाला वायरल बुखार।'],
  ['benign', 'सामान्यतः हानिरहित (कैंसर वाला नहीं)।'],
  ['malignant', 'कैंसर वाला।'],
  ['chronic', 'लंबे समय तक चलने वाला।'],
  ['acute', 'अचानक शुरू होने वाला और आम तौर पर कम समय का।'],
  ['od', 'दवा दिन में एक बार।'],
  ['bd', 'दवा दिन में दो बार।'],
  ['tds', 'दवा दिन में तीन बार।'],
  ['hs', 'दवा रात को सोने से पहले।'],
  ['sos', 'दवा सिर्फ़ ज़रूरत पड़ने पर।'],
  ['ac', 'दवा खाना खाने से पहले।'],
  ['pc', 'दवा खाना खाने के बाद।']
];
