/* Vitalis — client-side demo app. Data lives in localStorage (no server). */
(() => {
'use strict';
const KEY = 'vitalis_v1';
const $ = (s, r = document) => r.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const uid = (p = 'x') => p + Math.random().toString(36).slice(2, 9);
const pad = n => String(n).padStart(2, '0');
const iso = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const today = () => iso(new Date());
const addDays = n => { const d = new Date(); d.setDate(d.getDate() + n); return iso(d); };
const fmt = s => s ? new Date(s + 'T00:00:00').toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }) : '—';
const helpers = { addDays };

/* ---------- state ---------- */
function load() {
  try { const s = JSON.parse(localStorage.getItem(KEY)); if (s && s.profiles) return s; } catch (e) {}
  return window.VITALIS_SEED(helpers);
}
let state = load();
const save = () => { try { localStorage.setItem(KEY, JSON.stringify(state)); } catch (e) {} };
const profile = () => state.profiles.find(p => p.id === state.activeId) || state.profiles[0];
const sortedVisits = p => [...p.visits].sort((a, b) => (b.date || '').localeCompare(a.date || ''));

function toast(msg) {
  const t = $('#toast'); t.textContent = msg; t.classList.add('show');
  clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.remove('show'), 2800);
}
function copyText(txt) {
  if (navigator.clipboard) return navigator.clipboard.writeText(txt).then(() => toast('Copied'), () => toast('Copy failed'));
  const ta = document.createElement('textarea'); ta.value = txt; document.body.appendChild(ta); ta.select();
  try { document.execCommand('copy'); toast('Copied'); } catch (e) { toast('Copy failed'); } ta.remove();
}

/* ---------- Care Gap Radar ---------- */
function computeGaps(p) {
  const g = [];
  if (p.allergyStatus === 'unknown') g.push({ msg: 'Allergy status is not recorded. Confirm: any allergy, or none?', act: 'edit-basics' });
  p.visits.forEach(v => {
    const label = `${v.reason || 'Visit'}${v.date ? ' (' + fmt(v.date) + ')' : ''}`;
    if (!v.date) g.push({ vid: v.id, msg: `Visit date is missing — ${label}`, act: 'edit-visit', id: v.id });
    if (!v.doctor) g.push({ vid: v.id, msg: `Doctor name is missing — ${label}`, act: 'edit-visit', id: v.id });
    (v.medicines || []).forEach(m => {
      if (!m.dose) g.push({ vid: v.id, msg: `Dose is missing for ${m.name} — ${label}`, act: 'edit-visit', id: v.id });
    });
    if (v.followUpAdvised && !p.followUps.some(f => f.visitId === v.id))
      g.push({ vid: v.id, msg: `Follow-up was advised after ${label}, but none is tracked`, act: 'add-followup', id: v.id });
  });
  p.followUps.forEach(f => {
    if (f.status === 'pending' && f.date && f.date < today())
      g.push({ vid: f.visitId, msg: `"${f.title}" was due on ${fmt(f.date)}. Is it done?`, act: 'update-followup', id: f.id });
  });
  if (!p.emergency) g.push({ msg: 'No emergency contact added', act: 'edit-basics' });
  return g;
}
const gapBtn = g => {
  const label = { 'edit-basics': 'Update', 'edit-visit': 'Fix', 'add-followup': 'Track it', 'update-followup': 'Update status' }[g.act];
  return `<button class="btn ghost sm" data-act="${g.act}" data-id="${esc(g.id || '')}">${label}</button>`;
};

/* ---------- views ---------- */
function loginView() {
  return `<div class="login"><div class="card">
    <div class="brand" style="color:var(--ink)">Vitalis</div>
    <div class="tag">Your health story should never start from zero.</div>
    <p class="muted">Keep every visit, prescription and follow-up in one place, and walk into any clinic prepared.</p>
    <p class="small muted">Demo mode: a fictional patient (Ramesh Verma) is loaded. Data stays in this browser only.</p>
    <button class="btn" style="width:100%;margin-top:8px" data-act="login">Open demo patient</button>
    <button class="btn ghost" style="width:100%;margin-top:8px" data-act="reset-demo">Reset demo data</button>
  </div></div>`;
}

function shell(route, body) {
  const p = profile();
  const links = [['dashboard', 'Health timeline'], ['brief', "Doctor's 30-sec brief"], ['followups', 'Follow-up guardian'],
    ['share', 'Share & emergency'], ['family', 'Family circle'], ['translate', 'Record translator']];
  return `<div class="shell"><aside class="side">
    <div class="brand">Vitalis<small>Your personal health memory</small></div>
    <div><label for="who" style="color:#9FB3C2;margin:0 0 4px">Viewing profile</label>
      <select id="who" data-change="switch-profile">${state.profiles.map(x => `<option value="${x.id}" ${x.id === p.id ? 'selected' : ''}>${esc(x.name)} (${esc(x.relation)})</option>`).join('')}</select></div>
    <nav class="nav" aria-label="Main">${links.map(([r, t]) => `<a href="#/${r}" class="${r === route ? 'on' : ''}">${t}</a>`).join('')}</nav>
    <button class="btn ghost" data-act="logout">Log out</button>
  </aside><main>${body}</main></div>`;
}

function remindersBanner(p) {
  const soon = p.followUps.filter(f => f.status === 'pending' && f.date && f.date <= addDays(2));
  if (!soon.length) return '';
  return `<div class="banner"><b>Reminder:</b> ${soon.map(f => `${esc(f.title)} (${f.date < today() ? 'overdue since ' : 'due '}${fmt(f.date)})`).join('; ')}.
    <a href="#/followups">Open follow-ups</a></div>`;
}

function dashboard(p) {
  const gaps = computeGaps(p);
  const pending = p.followUps.filter(f => f.status === 'pending');
  const visits = sortedVisits(p);
  const timeline = visits.length ? `<div class="tl">${visits.map(v => {
    const vg = gaps.filter(x => x.vid === v.id);
    return `<article class="visit card ${vg.length ? 'hasgap' : ''}">
      <div class="when">${fmt(v.date)}</div>
      <h3>${esc(v.reason || 'Visit')}</h3>
      <div class="muted small">${esc(v.doctor || 'Doctor not recorded')}${v.hospital ? ' · ' + esc(v.hospital) : ''}</div>
      ${v.notes ? `<p>${esc(v.notes)}</p>` : ''}
      ${(v.medicines || []).length ? `<b class="small">Medicines</b><ul>${v.medicines.map(m => `<li>${esc(m.name)}${m.dose ? ' — ' + esc(m.dose) : ' — <mark>dose missing</mark>'}</li>`).join('')}</ul>` : ''}
      ${(v.reports || []).length ? `<b class="small">Reports</b><ul>${v.reports.map(r => `<li>${esc(r.name)}</li>`).join('')}</ul>` : ''}
      <div class="row">${vg.map(x => `<span class="chip gap">${esc(x.msg.split(' — ')[0])}</span>`).join('')}
        <span class="right"></span>
        <button class="btn ghost sm" data-act="edit-visit" data-id="${v.id}">Edit</button>
        <button class="btn danger sm" data-act="del-visit" data-id="${v.id}">Delete</button></div>
    </article>`;
  }).join('')}</div>` : `<div class="card"><p>No visits yet for ${esc(p.name)}. Add the first visit to start the timeline.</p></div>`;

  return `${remindersBanner(p)}
  <div class="head"><div><h1>${esc(p.name)}</h1><div class="muted">${esc(p.relation)}${p.age ? ' · ' + p.age + ' yrs' : ''}${p.bloodGroup ? ' · Blood group ' + esc(p.bloodGroup) : ''}</div></div>
    <button class="btn right" data-act="add-visit">Add a visit</button></div>
  <div class="stats">
    <div class="stat"><b>${p.visits.length}</b>visits recorded</div>
    <div class="stat"><b style="color:${gaps.length ? 'var(--amber)' : 'var(--teal)'}">${gaps.length}</b>care gaps to verify</div>
    <div class="stat"><b>${pending.length}</b>pending follow-ups</div></div>
  <div class="grid2"><section><h2>Health memory</h2>${timeline}</section>
  <aside><div class="card"><h2>Care Gap Radar</h2>
    ${gaps.length ? `<p class="small muted">Missing or unclear information. Please verify:</p><ul class="list">${gaps.map(g => `<li>${esc(g.msg)}<div style="margin-top:6px">${gapBtn(g)}</div></li>`).join('')}</ul>`
      : '<p>No gaps found. Records look complete.</p>'}</div>
  <div class="card"><h2>Basics</h2>
    <p class="small"><b>Allergies:</b> ${allergyText(p)}</p>
    <p class="small"><b>Conditions:</b> ${p.conditions.length ? esc(p.conditions.join(', ')) : 'Not recorded'}</p>
    <p class="small"><b>Emergency contact:</b> ${p.emergency ? esc(p.emergency.name + ' · ' + p.emergency.phone) : 'Not added'}</p>
    <button class="btn ghost sm" data-act="edit-basics">Edit basics</button></div></aside></div>`;
}
function allergyText(p) {
  if (p.allergyStatus === 'unknown') return '<mark>Not recorded</mark>';
  if (p.allergyStatus === 'none') return 'None (confirmed by patient)';
  return esc(p.allergies.join(', ') || 'Listed, but empty');
}

/* Doctor's brief */
function briefData(p) {
  const cutoff = addDays(-180), meds = new Map();
  sortedVisits(p).slice().reverse().forEach(v => { if ((v.date || '') >= cutoff) (v.medicines || []).forEach(m => meds.set(m.name.toLowerCase(), { ...m, date: v.date })); });
  return {
    meds: [...meds.values()],
    visits: sortedVisits(p).slice(0, 3),
    reports: sortedVisits(p).flatMap(v => (v.reports || []).map(r => ({ name: r.name, date: v.date }))),
    pending: p.followUps.filter(f => f.status === 'pending'),
    gaps: computeGaps(p)
  };
}
function briefText(p) {
  const b = briefData(p), L = [];
  L.push(`DOCTOR'S BRIEF — ${p.name}${p.age ? ', ' + p.age + ' yrs' : ''}${p.bloodGroup ? ', ' + p.bloodGroup : ''}`);
  L.push(`Allergies: ${p.allergyStatus === 'unknown' ? 'NOT RECORDED — verify' : p.allergyStatus === 'none' ? 'None reported' : p.allergies.join(', ')}`);
  L.push(`Known conditions: ${p.conditions.join(', ') || 'Not recorded'}`);
  L.push('Medicines (last 6 months): ' + (b.meds.map(m => `${m.name}${m.dose ? ' ' + m.dose : ' (dose?)'}`).join('; ') || 'None recorded'));
  L.push('Recent visits:'); b.visits.forEach(v => L.push(`- ${fmt(v.date)}: ${v.reason}${v.doctor ? ' (' + v.doctor + ')' : ''}`));
  L.push('Reports available: ' + (b.reports.map(r => r.name).join('; ') || 'None'));
  L.push('Pending follow-ups: ' + (b.pending.map(f => `${f.title} (${fmt(f.date)})`).join('; ') || 'None'));
  L.push('Compiled from patient-entered records. Not a diagnosis.');
  return L.join('\n');
}
function brief(p) {
  const b = briefData(p);
  return `<div class="head"><div><h1>Doctor's 30-second brief</h1><div class="muted">One page, ready for the clinic.</div></div>
    <span class="right row no-print"><button class="btn ghost" data-act="copy-brief">Copy text</button><button class="btn" data-act="print">Print</button></span></div>
  <div class="card brief">
    <h2>${esc(p.name)}${p.age ? ', ' + p.age : ''}${p.bloodGroup ? ' · ' + esc(p.bloodGroup) : ''}</h2>
    <h3>Allergies</h3><p>${allergyText(p)}</p>
    <h3>Known conditions</h3><p>${p.conditions.length ? esc(p.conditions.join(', ')) : 'Not recorded'}</p>
    <h3>Medicines from the last 6 months</h3>${b.meds.length ? `<ul>${b.meds.map(m => `<li>${esc(m.name)}${m.dose ? ' — ' + esc(m.dose) : ' — <mark>dose not recorded</mark>'}</li>`).join('')}</ul>` : '<p>None recorded</p>'}
    <h3>Recent visits</h3>${b.visits.length ? `<ul>${b.visits.map(v => `<li>${fmt(v.date)} — ${esc(v.reason)}${v.doctor ? ', ' + esc(v.doctor) : ''}</li>`).join('')}</ul>` : '<p>None</p>'}
    <h3>Reports available</h3>${b.reports.length ? `<ul>${b.reports.map(r => `<li>${esc(r.name)} (${fmt(r.date)})</li>`).join('')}</ul>` : '<p>None</p>'}
    <h3>Pending follow-ups</h3>${b.pending.length ? `<ul>${b.pending.map(f => `<li>${esc(f.title)} — ${fmt(f.date)}</li>`).join('')}</ul>` : '<p>None</p>'}
    <h3>Still to verify</h3>${b.gaps.length ? `<ul>${b.gaps.slice(0, 5).map(g => `<li>${esc(g.msg)}</li>`).join('')}</ul>` : '<p>Nothing</p>'}
    <p class="small muted" style="margin-top:16px">Compiled from patient-entered records. This is not a diagnosis.</p>
  </div>`;
}

/* Follow-ups */
function followups(p) {
  const list = [...p.followUps].sort((a, b) => (a.date || '').localeCompare(b.date || ''));
  const chip = f => f.status === 'completed' ? '<span class="chip">Completed</span>' : f.status === 'rescheduled' ? '<span class="chip gap">Rescheduled</span>' : (f.date < today() ? '<span class="chip bad">Overdue</span>' : '<span class="chip gap">Pending</span>');
  return `${remindersBanner(p)}<div class="head"><div><h1>Follow-up guardian</h1><div class="muted">Tests and appointments your doctor advised.</div></div>
    <span class="right row"><button class="btn ghost" data-act="notif-enable">Enable reminders</button><button class="btn" data-act="add-followup">Add follow-up</button></span></div>
  <div class="card">${list.length ? `<ul class="list">${list.map(f => `<li class="row"><div><b>${esc(f.title)}</b><div class="small muted">${fmt(f.date)}</div></div>
    <span class="right row">${chip(f)}<button class="btn ghost sm" data-act="update-followup" data-id="${f.id}">Update</button><button class="btn danger sm" data-act="del-followup" data-id="${f.id}">Delete</button></span></li>`).join('')}</ul>`
    : '<p>No follow-ups yet. Add one after your next doctor visit.</p>'}</div>`;
}

/* Share & emergency passport */
const SHARE_FIELDS = [['allergies', 'Allergies'], ['meds', 'Current medicines'], ['conditions', 'Known conditions'], ['blood', 'Blood group'],
  ['contact', 'Emergency contact'], ['visits', 'Recent visits'], ['reports', 'Report names']];
function share(p) {
  const mine = state.shares.filter(s => s.profileId === p.id);
  const link = s => location.href.split('#')[0] + '#/shared/' + s.token;
  return `<div class="head"><div><h1>Share & emergency passport</h1><div class="muted">Choose what to share. Access expires and can be revoked.</div></div></div>
  <div class="grid2"><section class="card"><h2>Create a share link</h2>
    <form data-form="share">${SHARE_FIELDS.map(([k, t], i) => `<label class="check"><input type="checkbox" name="f" value="${k}" ${i < 5 ? 'checked' : ''}> ${t}</label>`).join('')}
      <label for="dur">Access lasts</label><select id="dur" name="dur"><option value="1">1 hour</option><option value="24" selected>24 hours</option><option value="168">7 days</option></select>
      <p><button class="btn">Create link</button></p></form></section>
  <section class="card"><h2>Active links</h2>${mine.length ? `<ul class="list">${mine.map(s => {
    const live = !s.revoked && s.expires > Date.now();
    return `<li><span class="chip ${live ? '' : 'bad'}">${s.revoked ? 'Revoked' : live ? 'Active' : 'Expired'}</span>
      <div class="small muted">${s.fields.length} items · until ${new Date(s.expires).toLocaleString('en-IN')}</div>
      <div class="row" style="margin-top:6px">${live ? `<a class="btn ghost sm" href="${link(s)}" target="_blank" rel="noopener">Open as doctor</a>
      <button class="btn ghost sm" data-act="copy-link" data-token="${s.token}">Copy link</button>
      <button class="btn danger sm" data-act="revoke" data-id="${s.id}">Revoke</button>` : ''}</div></li>`;
  }).join('')}</ul>` : '<p>No links yet.</p>'}
  <p class="small muted">Demo note: links open in the same browser. A real deployment would store shares on a server.</p></section></div>`;
}
function sharedView(token) {
  const s = state.shares.find(x => x.token === token);
  if (!s || s.revoked || s.expires < Date.now())
    return `<div class="login"><div class="card"><h2>Link not available</h2><p>This share link has expired or was revoked by the patient.</p></div></div>`;
  const p = state.profiles.find(x => x.id === s.profileId), has = k => s.fields.includes(k), b = briefData(p);
  return `<main style="margin:auto"><div class="banner info"><b>Shared by patient · read-only.</b> Access ends ${new Date(s.expires).toLocaleString('en-IN')}.</div>
  <div class="card brief"><h2>${esc(p.name)}${p.age ? ', ' + p.age : ''}</h2>
    ${has('blood') ? `<h3>Blood group</h3><p>${esc(p.bloodGroup || 'Not recorded')}</p>` : ''}
    ${has('allergies') ? `<h3>Allergies</h3><p>${allergyText(p)}</p>` : ''}
    ${has('conditions') ? `<h3>Known conditions</h3><p>${esc(p.conditions.join(', ') || 'Not recorded')}</p>` : ''}
    ${has('meds') ? `<h3>Current medicines</h3><ul>${b.meds.map(m => `<li>${esc(m.name)} ${esc(m.dose)}</li>`).join('') || '<li>None recorded</li>'}</ul>` : ''}
    ${has('contact') ? `<h3>Emergency contact</h3><p>${p.emergency ? esc(p.emergency.name) + ' — <a href="tel:' + esc(p.emergency.phone) + '">' + esc(p.emergency.phone) + '</a>' : 'Not added'}</p>` : ''}
    ${has('visits') ? `<h3>Recent visits</h3><ul>${b.visits.map(v => `<li>${fmt(v.date)} — ${esc(v.reason)}</li>`).join('') || '<li>None</li>'}</ul>` : ''}
    ${has('reports') ? `<h3>Reports</h3><ul>${b.reports.map(r => `<li>${esc(r.name)}</li>`).join('') || '<li>None</li>'}</ul>` : ''}
  </div></main>`;
}

/* Family */
function family() {
  return `<div class="head"><div><h1>Family health circle</h1><div class="muted">Every member has a separate profile and separate records.</div></div>
    <button class="btn right" data-act="add-member">Add member</button></div>
  <div class="grid2">${state.profiles.map(p => `<div class="card"><h3>${esc(p.name)}</h3><div class="muted small">${esc(p.relation)}${p.age ? ' · ' + p.age + ' yrs' : ''}</div>
    <p class="small">${p.visits.length} visits · ${computeGaps(p).length} gaps</p>
    <div class="row"><button class="btn ghost sm" data-act="open-profile" data-id="${p.id}">Open profile</button>
    ${state.profiles.length > 1 ? `<button class="btn danger sm" data-act="del-member" data-id="${p.id}">Remove</button>` : ''}</div></div>`).join('')}</div>`;
}

/* Translator */
const SAMPLE = 'Patient has Hypertension and Diabetes mellitus. HbA1c 7.9%. Tab Metformin 500mg BD pc. Tab Amlodipine 5mg OD. Advised fasting lipid profile and ECG. Review after 3 months.';
function translate() {
  return `<div class="head"><div><h1>Health record translator</h1><div class="muted">Medical terms in simple Hindi.</div></div></div>
  <div class="card"><form data-form="translate"><label for="rt">Paste text from a prescription or report</label>
    <textarea id="rt" name="t" placeholder="e.g. Hypertension, HbA1c, Tab Metformin 500mg BD"></textarea>
    <div class="row" style="margin-top:10px"><button class="btn">Explain in Hindi</button><button type="button" class="btn ghost" data-act="sample">Use sample</button></div></form>
    <div id="tr-out"></div>
    <p class="small muted">This explains terms only. It does not diagnose or suggest treatment. Please ask your doctor about your results.</p></div>`;
}
function explain(text) {
  const found = [], low = text.toLowerCase();
  window.VITALIS_TERMS.forEach(([t, h]) => {
    const re = new RegExp('(^|[^a-z0-9])' + t.replace(/[.*+?^${}()|[\]\\-]/g, '\\$&') + '($|[^a-z0-9])', 'i');
    if (re.test(low) && !found.some(f => f[1] === h)) found.push([t, h]);
  });
  return found.length ? found.map(([t, h]) => `<div class="term"><b>${esc(t.toUpperCase())}</b><br>${esc(h)}</div>`).join('')
    : '<p>No known terms found. Try pasting more of the report.</p>';
}

/* ---------- modals ---------- */
const modal = $('#modal');
function openModal(html) { modal.innerHTML = html; if (!modal.open) modal.showModal(); }
const closeBtn = '<button type="button" class="btn ghost" data-act="close">Cancel</button>';

function visitForm(v) {
  const e = !!v; v = v || { date: today(), medicines: [], reports: [] };
  return `<h2>${e ? 'Edit visit' : 'Add a visit'}</h2>
  ${e ? '' : `<div class="card" style="margin-bottom:14px"><b>Speak in Hindi or Hinglish</b>
    <p class="small muted">Example: "Kal Dr. Sharma ko dikhaya, bukhar tha, Paracetamol 500 mg di."</p>
    <div class="row"><button type="button" class="btn ghost sm" data-act="voice-start">Start speaking</button></div>
    <textarea id="voiceText" placeholder="Speech or typed text appears here"></textarea>
    <button type="button" class="btn sm" data-act="voice-draft" style="margin-top:8px">Make draft</button></div><div id="draftNote"></div>`}
  <form id="visitForm" data-form="visit" data-id="${e ? v.id : ''}">
    <div class="cols"><div><label for="vd">Date</label><input type="date" id="vd" name="date" value="${esc(v.date || '')}"></div>
    <div><label for="vdoc">Doctor</label><input type="text" id="vdoc" name="doctor" value="${esc(v.doctor || '')}"></div></div>
    <label for="vh">Hospital / clinic</label><input type="text" id="vh" name="hospital" value="${esc(v.hospital || '')}">
    <label for="vr">Reason for visit</label><input type="text" id="vr" name="reason" value="${esc(v.reason || '')}" required>
    <label for="vn">Doctor's notes</label><textarea id="vn" name="notes">${esc(v.notes || '')}</textarea>
    <label for="vm">Medicines (one per line: name, dose)</label><textarea id="vm" name="meds" placeholder="Metformin, 500mg BD">${esc((v.medicines || []).map(m => m.name + (m.dose ? ', ' + m.dose : '')).join('\n'))}</textarea>
    <label for="vrep">Reports (one per line)</label><textarea id="vrep" name="reports">${esc((v.reports || []).map(r => r.name).join('\n'))}</textarea>
    <label class="check"><input type="checkbox" name="fu" ${v.followUpAdvised ? 'checked' : ''}> Doctor advised a follow-up</label>
    ${e ? '' : `<div class="cols"><div><label for="fut">Follow-up for</label><input type="text" id="fut" name="fuTitle" placeholder="e.g. Repeat blood test"></div>
    <div><label for="fud">Follow-up date</label><input type="date" id="fud" name="fuDate"></div></div>`}
    <div class="row" style="margin-top:16px"><button class="btn">Save visit</button>${closeBtn}</div></form>`;
}
const basicsForm = p => `<h2>Edit basics — ${esc(p.name)}</h2><form data-form="basics">
  <label>Allergies</label>
  <label class="check"><input type="radio" name="as" value="unknown" ${p.allergyStatus === 'unknown' ? 'checked' : ''}> Not sure yet</label>
  <label class="check"><input type="radio" name="as" value="none" ${p.allergyStatus === 'none' ? 'checked' : ''}> No known allergies</label>
  <label class="check"><input type="radio" name="as" value="listed" ${p.allergyStatus === 'listed' ? 'checked' : ''}> Has allergies:</label>
  <input type="text" name="al" value="${esc(p.allergies.join(', '))}" placeholder="Penicillin, dust (comma separated)" aria-label="Allergy list">
  <label for="bc">Known conditions (comma separated)</label><input type="text" id="bc" name="cond" value="${esc(p.conditions.join(', '))}">
  <div class="cols"><div><label for="bg">Blood group</label><input type="text" id="bg" name="bg" value="${esc(p.bloodGroup)}"></div>
  <div><label for="age">Age</label><input type="number" id="age" name="age" value="${esc(p.age || '')}"></div></div>
  <div class="cols"><div><label for="en">Emergency contact name</label><input type="text" id="en" name="en" value="${esc(p.emergency?.name || '')}"></div>
  <div><label for="ep">Emergency contact phone</label><input type="tel" id="ep" name="ep" value="${esc(p.emergency?.phone || '')}"></div></div>
  <div class="row" style="margin-top:16px"><button class="btn">Save</button>${closeBtn}</div></form>`;
const followupForm = (vid, p) => `<h2>Add follow-up</h2><form data-form="followup">
  <label for="ft">What is it for?</label><input type="text" id="ft" name="title" required value="${esc(vid ? 'Follow-up: ' + (p.visits.find(v => v.id === vid)?.reason || '') : '')}">
  <label for="fd">Date</label><input type="date" id="fd" name="date" required><input type="hidden" name="vid" value="${esc(vid || '')}">
  <div class="row" style="margin-top:16px"><button class="btn">Save follow-up</button>${closeBtn}</div></form>`;
const updateForm = f => `<h2>Update: ${esc(f.title)}</h2><form data-form="update-followup" data-id="${f.id}">
  <label for="us">Status</label><select id="us" name="status">${['pending', 'completed', 'rescheduled'].map(s => `<option value="${s}" ${f.status === s ? 'selected' : ''}>${s[0].toUpperCase() + s.slice(1)}</option>`).join('')}</select>
  <label for="ud">Date (set a new date if rescheduled)</label><input type="date" id="ud" name="date" value="${esc(f.date)}">
  <div class="row" style="margin-top:16px"><button class="btn">Save</button>${closeBtn}</div></form>`;
const memberForm = () => `<h2>Add family member</h2><form data-form="member">
  <label for="mn">Name</label><input type="text" id="mn" name="name" required>
  <div class="cols"><div><label for="mr">Relation</label><input type="text" id="mr" name="relation" placeholder="Mother, Son…" required></div>
  <div><label for="ma">Age</label><input type="number" id="ma" name="age"></div></div>
  <div class="row" style="margin-top:16px"><button class="btn">Add member</button>${closeBtn}</div></form>`;

/* ---------- voice (Web Speech API, Chrome/Edge) ---------- */
let rec = null;
const KNOWN_MEDS = ['paracetamol', 'crocin', 'dolo', 'azithromycin', 'amoxicillin', 'metformin', 'amlodipine', 'pantoprazole', 'cetirizine', 'ibuprofen', 'atorvastatin', 'telmisartan', 'losartan', 'omeprazole', 'aspirin', 'levothyroxine', 'insulin'];
const DEV_MEDS = { 'पैरासिटामोल': 'Paracetamol', 'क्रोसिन': 'Crocin', 'डोलो': 'Dolo', 'मेटफॉर्मिन': 'Metformin', 'अमोक्सिसिलिन': 'Amoxicillin', 'एज़िथ्रोमाइसिन': 'Azithromycin' };
const SYMPTOMS = [[/bukhar|बुखार|fever/i, 'Fever'], [/khansi|खांसी|खाँसी|cough/i, 'Cough'], [/sar dard|सिर दर्द|headache/i, 'Headache'],
  [/pet dard|पेट दर्द|stomach/i, 'Stomach pain'], [/sugar|शुगर|diabetes|मधुमेह/i, 'Diabetes check'], [/\bbp\b|ब्लड प्रेशर|blood pressure/i, 'BP check'],
  [/gala|गला|throat/i, 'Sore throat'], [/jukam|ज़ुकाम|जुकाम|सर्दी|cold/i, 'Cold']];
function parseVoice(text) {
  const out = { date: today(), doctor: '', hospital: '', reason: '', meds: [] }, low = text.toLowerCase();
  if (/parso|परसों/.test(low)) out.date = addDays(-2); else if (/\bkal\b|कल/.test(low)) out.date = addDays(-1);
  const d = text.match(/(?:dr\.?|doctor|डॉक्टर|डॉ\.?)\s*([A-Za-z\u0900-\u097F]+)/i); if (d) out.doctor = 'Dr. ' + d[1];
  const h = text.match(/([A-Za-z\u0900-\u097F]+\s+(?:hospital|अस्पताल|clinic|क्लिनिक))/i); if (h) out.hospital = h[1];
  out.reason = SYMPTOMS.filter(([re]) => re.test(text)).map(s => s[1]).join(', ') || text.slice(0, 60);
  const names = [...KNOWN_MEDS.filter(m => low.includes(m)).map(m => [m, low.indexOf(m), m[0].toUpperCase() + m.slice(1)]),
    ...Object.entries(DEV_MEDS).filter(([k]) => text.includes(k)).map(([k, v]) => [k, text.indexOf(k), v])];
  names.forEach(([k, i, nm]) => { const dose = text.slice(i + k.length, i + k.length + 25).match(/(\d+(?:\.\d+)?\s?(?:mg|ml|mcg|g)\b)/i); out.meds.push(nm + (dose ? ', ' + dose[1] : '')); });
  return out;
}

/* ---------- actions ---------- */
const A = {
  login() { state.user = { name: 'Demo' }; save(); location.hash = '#/dashboard'; render(); },
  logout() { state.user = null; save(); render(); },
  'reset-demo'() { state = window.VITALIS_SEED(helpers); save(); toast('Demo data reset'); render(); },
  close() { modal.close(); },
  print() { window.print(); },
  'copy-brief'() { copyText(briefText(profile())); },
  'copy-link'(d) { copyText(location.href.split('#')[0] + '#/shared/' + d.token); },
  sample() { $('#rt').value = SAMPLE; },
  'add-visit'() { openModal(visitForm()); },
  'edit-visit'(d) { const v = profile().visits.find(x => x.id === d.id); if (v) openModal(visitForm(v)); },
  'del-visit'(d) { if (confirm('Delete this visit?')) { const p = profile(); p.visits = p.visits.filter(v => v.id !== d.id); save(); render(); } },
  'edit-basics'() { openModal(basicsForm(profile())); },
  'add-followup'(d) { openModal(followupForm(d.id, profile())); },
  'update-followup'(d) { const f = profile().followUps.find(x => x.id === d.id); if (f) openModal(updateForm(f)); },
  'del-followup'(d) { const p = profile(); p.followUps = p.followUps.filter(f => f.id !== d.id); save(); render(); },
  'add-member'() { openModal(memberForm()); },
  'open-profile'(d) { state.activeId = d.id; save(); location.hash = '#/dashboard'; render(); },
  'del-member'(d) { if (confirm('Remove this profile and all its records?')) { state.profiles = state.profiles.filter(p => p.id !== d.id); state.shares = state.shares.filter(s => s.profileId !== d.id); if (state.activeId === d.id) state.activeId = state.profiles[0].id; save(); render(); } },
  revoke(d) { const s = state.shares.find(x => x.id === d.id); if (s) s.revoked = true; save(); toast('Access revoked'); render(); },
  'notif-enable'() {
    if (!('Notification' in window)) return toast('Notifications are not supported here');
    Notification.requestPermission().then(r => { toast(r === 'granted' ? 'Reminders enabled' : 'Permission not granted'); notifyDue(); });
  },
  'voice-start'(d, btn) {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) return toast('Voice input needs Chrome or Edge. You can type in the box instead.');
    if (rec) { rec.stop(); return; }
    rec = new SR(); rec.lang = 'hi-IN'; rec.interimResults = true; rec.continuous = true;
    rec.onresult = ev => { let t = ''; for (const r of ev.results) t += r[0].transcript + ' '; $('#voiceText').value = t.trim(); };
    rec.onend = () => { rec = null; btn.textContent = 'Start speaking'; };
    rec.onerror = () => toast('Microphone not available. Check browser permission.');
    rec.start(); btn.textContent = 'Stop';
  },
  'voice-draft'() {
    const t = $('#voiceText').value.trim(); if (!t) return toast('Speak or type something first');
    const r = parseVoice(t), f = $('#visitForm');
    f.date.value = r.date; f.doctor.value = r.doctor; f.hospital.value = r.hospital; f.reason.value = r.reason; f.meds.value = r.meds.join('\n'); f.notes.value = t;
    $('#draftNote').innerHTML = '<div class="banner info"><b>Draft ready.</b> Please check every field below. Nothing is saved until you press "Save visit". ("Kal" is read as yesterday.)</div>';
  }
};
const C = { 'switch-profile'(el) { state.activeId = el.value; save(); render(); } };

const lines = s => s.split('\n').map(x => x.trim()).filter(Boolean);
const F = {
  visit(f, fd) {
    const p = profile(), id = f.dataset.id;
    const v = id ? p.visits.find(x => x.id === id) : { id: uid('v') };
    Object.assign(v, { date: fd.get('date'), doctor: fd.get('doctor').trim(), hospital: fd.get('hospital').trim(), reason: fd.get('reason').trim(), notes: fd.get('notes').trim(),
      medicines: lines(fd.get('meds')).map(l => { const i = l.search(/[,|]/); return i < 0 ? { name: l, dose: '' } : { name: l.slice(0, i).trim(), dose: l.slice(i + 1).trim() }; }),
      reports: lines(fd.get('reports')).map(name => ({ name })), followUpAdvised: fd.get('fu') === 'on' });
    if (!id) p.visits.push(v);
    if (!id && v.followUpAdvised && fd.get('fuDate')) p.followUps.push({ id: uid('f'), title: fd.get('fuTitle').trim() || 'Follow-up: ' + v.reason, date: fd.get('fuDate'), status: 'pending', visitId: v.id });
    toast('Visit saved');
  },
  basics(f, fd) {
    const p = profile(); p.allergyStatus = fd.get('as');
    p.allergies = p.allergyStatus === 'listed' ? fd.get('al').split(',').map(s => s.trim()).filter(Boolean) : [];
    if (p.allergyStatus === 'listed' && !p.allergies.length) p.allergyStatus = 'unknown';
    p.conditions = fd.get('cond').split(',').map(s => s.trim()).filter(Boolean);
    p.bloodGroup = fd.get('bg').trim(); p.age = Number(fd.get('age')) || p.age;
    p.emergency = fd.get('en').trim() && fd.get('ep').trim() ? { name: fd.get('en').trim(), phone: fd.get('ep').trim() } : null;
    toast('Saved');
  },
  followup(f, fd) { profile().followUps.push({ id: uid('f'), title: fd.get('title').trim(), date: fd.get('date'), status: 'pending', visitId: fd.get('vid') || null }); toast('Follow-up added'); },
  'update-followup'(f, fd) { const x = profile().followUps.find(y => y.id === f.dataset.id); x.status = fd.get('status'); if (fd.get('date')) x.date = fd.get('date'); toast('Follow-up updated'); },
  member(f, fd) { const id = uid('p'); state.profiles.push({ id, name: fd.get('name').trim(), relation: fd.get('relation').trim(), age: Number(fd.get('age')) || null, allergyStatus: 'unknown', allergies: [], conditions: [], bloodGroup: '', emergency: null, visits: [], followUps: [] }); toast('Member added'); },
  share(f, fd) {
    const fields = fd.getAll('f'); if (!fields.length) return toast('Select at least one item') || false;
    state.shares.push({ id: uid('s'), token: uid('t') + uid(''), profileId: profile().id, fields, expires: Date.now() + Number(fd.get('dur')) * 3600e3, revoked: false });
    toast('Link created');
  },
  translate(f, fd) { $('#tr-out').innerHTML = explain(fd.get('t')); return false; }
};

document.addEventListener('click', e => {
  const t = e.target.closest('[data-act]'); if (!t) return;
  if (A[t.dataset.act]) A[t.dataset.act](t.dataset, t);
});
document.addEventListener('change', e => { const t = e.target.closest('[data-change]'); if (t && C[t.dataset.change]) C[t.dataset.change](t); });
document.addEventListener('submit', e => {
  const f = e.target.closest('[data-form]'); if (!f) return;
  e.preventDefault();
  const r = F[f.dataset.form](f, new FormData(f));
  if (r === false) return;
  save(); if (modal.open) modal.close(); render();
});

/* ---------- reminders ---------- */
let notified = false;
function notifyDue() {
  if (notified || !('Notification' in window) || Notification.permission !== 'granted' || !state.user) return;
  const due = profile().followUps.filter(f => f.status === 'pending' && f.date <= addDays(2));
  if (due.length) { notified = true; new Notification('Vitalis follow-up reminder', { body: due.map(f => f.title).join(', ') }); }
}

/* ---------- router ---------- */
function render() {
  const [route, arg] = (location.hash.replace(/^#\/?/, '') || 'dashboard').split('/');
  const app = $('#app');
  if (route === 'shared') { app.innerHTML = sharedView(arg); return; }
  if (!state.user) { app.innerHTML = loginView(); return; }
  const views = { dashboard, brief, followups, share, family, translate };
  const key = views[route] ? route : 'dashboard';
  app.innerHTML = shell(key, views[key](profile()));
  notifyDue();
}
window.addEventListener('hashchange', render);
render();
})();
