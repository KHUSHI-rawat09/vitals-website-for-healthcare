# Vitalis — Your Personal Health Memory

"Your Health Story Should Never Start From Zero."

Hackathon demo. Pure HTML + CSS + JavaScript, no install, no build step.

## Run it
1. Unzip the folder.
2. Double-click `index.html` (use Chrome or Edge).
3. Or run `python -m http.server 8000` in this folder and open http://localhost:8000

Click "Open demo patient". Click "Reset demo data" on the login screen any time to restore the starting data.

## Features (all 8 from the idea)
| Feature | Where |
|---|---|
| Care Gap Radar | Right panel on Health timeline (missing allergy, doses, doctor name, overdue follow-ups, no emergency contact) |
| Health Memory | Health timeline (chronological visits, medicines, reports) |
| Doctor's 30-Second Brief | "Doctor's 30-sec brief" (copy or print) |
| Hindi Voice Health Entry | Add a visit > Start speaking (hi-IN). Draft is filled in, saved only after you confirm |
| Emergency Health Passport | Share & emergency: pick fields, set expiry, revoke any time |
| Family Health Circle | Family circle: separate profile and records per member |
| Follow-up Guardian | Follow-up guardian: pending / completed / rescheduled, in-app + browser reminders |
| Health Record Translator | Record translator: medical terms explained in simple Hindi (no diagnosis) |

## Demo script (2 minutes)
1. Login as Ramesh Verma. Show timeline and the amber hollow dots where information is missing.
2. Care Gap Radar: click "Update" on the allergy gap and record it.
3. Add a visit using voice: "Kal Dr. Sharma ko dikhaya, bukhar tha, Paracetamol 500 mg di." Review the draft, then save.
4. Open the Doctor's brief.
5. Share & emergency: create a link, click "Open as doctor", then revoke.
6. Follow-up guardian: mark the overdue HbA1c test as completed.
7. Record translator: click "Use sample".

## Honest limitations (say this to judges)
- Data is stored in the browser (localStorage). There is no server or real login. Share links only open in the same browser.
- Voice works only in Chrome/Edge and needs internet. The Hindi parser is rule-based (keywords for common medicines and symptoms), so the user always confirms the draft.
- The translator uses a built-in dictionary of ~45 terms.
- Google Fonts need internet; the page still works without them.

## Production plan
Backend (Node/Express or Django) + PostgreSQL, real authentication, encrypted file storage for reports, server-side share tokens with expiry and audit log, row-level access so one patient can never read another's data, LLM-based voice parsing, and a mobile app.

## Files
```
index.html
css/style.css
js/data.js   demo patient + Hindi term dictionary
js/app.js    all app logic
```
Vitalis is a record-organising tool. It does not diagnose or give medical advice.
